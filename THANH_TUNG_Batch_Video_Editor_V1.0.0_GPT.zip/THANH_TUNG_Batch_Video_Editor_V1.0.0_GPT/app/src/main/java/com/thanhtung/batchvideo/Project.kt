package com.thanhtung.batchvideo

import android.content.Context
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max

/** Coordinates (center x/y) and width are relative to each video's frame. */
data class Layer(
    var enabled: Boolean = false,
    var uri: String = "",
    var x: Float = .72f,
    var y: Float = .72f,
    var width: Float = .30f,
    var opacity: Float = 1f,
    var rotation: Float = 0f
) {
    fun json() = JSONObject().put("enabled", enabled).put("uri", uri).put("x", x.toDouble())
        .put("y", y.toDouble()).put("width", width.toDouble())
        .put("opacity", opacity.toDouble()).put("rotation", rotation.toDouble())
    companion object {
        fun read(o: JSONObject?) = Layer(
            o?.optBoolean("enabled", false) ?: false,
            o?.optString("uri", "") ?: "",
            (o?.optDouble("x", .72) ?: .72).toFloat().coerceIn(0f, 1f),
            (o?.optDouble("y", .72) ?: .72).toFloat().coerceIn(0f, 1f),
            (o?.optDouble("width", .30) ?: .30).toFloat().coerceIn(.03f, 1.8f),
            (o?.optDouble("opacity", 1.0) ?: 1.0).toFloat().coerceIn(0f, 1f),
            (o?.optDouble("rotation", 0.0) ?: 0.0).toFloat()
        )
    }
}

data class InsertClip(
    var uri: String,
    var name: String,
    var image: Boolean,
    var durationMs: Long = 3000L,
    /** Milliseconds into main footage AFTER head trim, only used for MIDDLE clips. */
    var atMs: Long = 0L
) {
    fun json() = JSONObject().put("uri", uri).put("name", name).put("image", image)
        .put("durationMs", durationMs).put("atMs", atMs)
    companion object {
        fun read(o: JSONObject) = InsertClip(o.optString("uri"), o.optString("name"),
            o.optBoolean("image"), o.optLong("durationMs", 3000).coerceAtLeast(100),
            o.optLong("atMs", 0).coerceAtLeast(0))
    }
}

data class EditState(
    var trimStartMs: Long = 0L,
    var trimEndMs: Long = 0L,
    var watermark: String = "THANH TUNG",
    var watermarkColor: Int = Color.WHITE,
    var textLayer: Layer = Layer(true, "", .77f, .89f, .23f, .9f),
    var imageLayer: Layer = Layer(),
    var videoLayer: Layer = Layer(false, "", .25f, .25f, .32f, 1f),
    var frameStyle: String = "NONE",
    var frameColor: Int = Color.WHITE,
    /** Border thickness is fraction of smaller frame dimension. */
    var frameThickness: Float = .008f,
    var videoTilt: Float = 0f,
    var intro: MutableList<InsertClip> = mutableListOf(),
    var middle: MutableList<InsertClip> = mutableListOf(),
    var outro: MutableList<InsertClip> = mutableListOf()
) {
    fun json(): JSONObject = JSONObject()
        .put("trimStartMs", trimStartMs).put("trimEndMs", trimEndMs)
        .put("watermark", watermark).put("watermarkColor", watermarkColor)
        .put("textLayer", textLayer.json()).put("imageLayer", imageLayer.json())
        .put("videoLayer", videoLayer.json()).put("frameStyle", frameStyle)
        .put("frameColor", frameColor).put("frameThickness", frameThickness.toDouble())
        .put("videoTilt", videoTilt.toDouble())
        .put("intro", JSONArray().apply { intro.forEach { put(it.json()) } })
        .put("middle", JSONArray().apply { middle.forEach { put(it.json()) } })
        .put("outro", JSONArray().apply { outro.forEach { put(it.json()) } })
    fun copyDeep(): EditState = read(json())
    companion object {
        fun read(o: JSONObject?): EditState {
            fun clips(name: String): MutableList<InsertClip> {
                val arr = o?.optJSONArray(name) ?: JSONArray()
                return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.let(InsertClip::read) }.toMutableList()
            }
            return EditState(
                max(0L, o?.optLong("trimStartMs", 0L) ?: 0L),
                max(0L, o?.optLong("trimEndMs", 0L) ?: 0L),
                o?.optString("watermark", "THANH TUNG") ?: "THANH TUNG",
                o?.optInt("watermarkColor", Color.WHITE) ?: Color.WHITE,
                if (o?.has("textLayer") == true) Layer.read(o.optJSONObject("textLayer"))
                else Layer(true, "", .77f, .89f, .23f, .9f),
                Layer.read(o?.optJSONObject("imageLayer")),
                if (o?.has("videoLayer") == true) Layer.read(o.optJSONObject("videoLayer"))
                else Layer(false, "", .25f, .25f, .32f, 1f),
                o?.optString("frameStyle", "NONE") ?: "NONE",
                o?.optInt("frameColor", Color.WHITE) ?: Color.WHITE,
                (o?.optDouble("frameThickness", .008) ?: .008).toFloat().coerceIn(.001f, .08f),
                (o?.optDouble("videoTilt", 0.0) ?: 0.0).toFloat().coerceIn(-45f,45f),
                clips("intro"), clips("middle"), clips("outro")
            )
        }
    }
}

data class VideoEntry(val uri: String, val name: String) {
    fun json() = JSONObject().put("uri", uri).put("name", name)
}

class Project(private val context: Context) {
    val videos = mutableListOf<VideoEntry>()
    val audios = mutableListOf<String>()
    val custom = mutableMapOf<String, EditState>()
    var shared = EditState()
    var outputTree = ""
    var selected = 0
    var useSeparate = false

    fun state(index: Int = selected): EditState {
        val uri = videos.getOrNull(index)?.uri
        return if (useSeparate && uri != null) custom.getOrPut(uri) { shared.copyDeep() } else shared
    }
    fun json() = JSONObject().apply {
        put("videos", JSONArray().apply { videos.forEach { put(it.json()) } })
        put("audios", JSONArray().apply { audios.forEach { put(it) } })
        put("custom", JSONObject().apply { custom.forEach { (k,v) -> put(k,v.json()) } })
        put("shared", shared.json())
        put("outputTree", outputTree).put("selected", selected).put("useSeparate", useSeparate)
    }
    fun restore(o: JSONObject) {
        videos.clear(); audios.clear(); custom.clear()
        val v = o.optJSONArray("videos") ?: JSONArray()
        for (i in 0 until v.length()) {
            val row = v.optJSONObject(i) ?: continue
            val uri = row.optString("uri")
            if (uri.isNotBlank()) videos.add(VideoEntry(uri, row.optString("name", "video")))
        }
        val a = o.optJSONArray("audios") ?: JSONArray()
        for (i in 0 until a.length()) { val u = a.optString(i); if (u.isNotBlank()) audios.add(u) }
        val c = o.optJSONObject("custom") ?: JSONObject()
        c.keys().forEach { custom[it] = EditState.read(c.optJSONObject(it)) }
        shared = EditState.read(o.optJSONObject("shared"))
        outputTree = o.optString("outputTree", "")
        selected = o.optInt("selected", 0).coerceIn(0, (videos.size-1).coerceAtLeast(0))
        useSeparate = o.optBoolean("useSeparate", false)
    }
    fun save() = context.getSharedPreferences("project", 0).edit().putString("snapshot",json().toString()).apply()
    fun load() { runCatching {
        context.getSharedPreferences("project", 0).getString("snapshot", null)?.let { restore(JSONObject(it)) }
    } }
    fun savePreset(name: String) = context.getSharedPreferences("presets", 0).edit()
        .putString(name.trim(), shared.json().toString()).apply()
    fun presets() = context.getSharedPreferences("presets", 0).all.keys.sorted()
    fun loadPreset(name: String) {
        val raw = context.getSharedPreferences("presets",0).getString(name,null) ?: return
        shared = EditState.read(JSONObject(raw)); useSeparate=false; save()
    }
}

object MediaInfo {
    data class SizeInfo(val width: Int, val height: Int, val durationMs: Long) {
        val aspect: Float get() = width.toFloat() / height.coerceAtLeast(1)
    }
    fun details(context: Context, uriString: String): SizeInfo {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, Uri.parse(uriString))
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot % 180 != 0) { val tmp=w; w=h; h=tmp }
            return SizeInfo(w.coerceAtLeast(1),h.coerceAtLeast(1),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L)
        } finally { r.release() }
    }
    fun title(context: Context, uri: Uri): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use {
            if (it.moveToFirst()) return it.getString(0) ?: "media"
        }
        return uri.lastPathSegment ?: "media"
    }
    fun isImage(context: Context, uri: Uri): Boolean =
        (context.contentResolver.getType(uri) ?: "").startsWith("image/") ||
            (uri.toString().substringAfterLast('.').lowercase() in listOf("jpg","jpeg","png","webp"))
}
