package com.thanhtung.batchvideo

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.text.TextWatcher
import android.text.Editable
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface
import android.graphics.Bitmap
import android.view.ViewGroup
import java.util.Locale

/** Native Vietnamese UI; no account, ads or cloud dependencies. */
class MainActivity:Activity() {
    companion object {
        private const val REQ_VIDEO=101
        private const val REQ_AUDIO=102
        private const val REQ_IMAGE_LAYER=103
        private const val REQ_VIDEO_LAYER=104
        private const val REQ_INTRO=105
        private const val REQ_MIDDLE=106
        private const val REQ_OUTRO=107
        private const val REQ_TREE=108
    }
    private lateinit var model:Project
    private lateinit var content:LinearLayout
    private var canvas:EditorCanvas?=null
    private lateinit var status:TextView
    private var pendingMiddleAtMs=0L
    private val colors=listOf(Color.WHITE,Color.BLACK,Color.YELLOW,Color.RED,Color.GREEN,Color.CYAN,Color.MAGENTA)
    private val frameStyles=linkedMapOf("NONE" to "Không khung","SOLID" to "Viền liền",
        "DASHED" to "Viền nét đứt","DOUBLE" to "Viền đôi","ROUNDED" to "Khung bo góc","CORNERS" to "Bốn góc")
    private val receiver=object:BroadcastReceiver(){
        override fun onReceive(context:Context?, intent:Intent?) {
            status.text="${intent?.getStringExtra("message") ?: ""} | OK ${intent?.getIntExtra("done",0)} | Lỗi ${intent?.getIntExtra("errors",0)}"
        }
    }
    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        window.statusBarColor=Color.rgb(15,23,42)
        model=Project(this);model.load()
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setBackgroundColor(0xfff3f6fa.toInt()) }
        val bar=TextView(this).apply {
            text="THANH TUNG  •  BATCH VIDEO EDITOR  V1.0.0 GPT"
            setTextColor(Color.WHITE);setBackgroundColor(0xff0f172a.toInt());textSize=15f
            setTypeface(null,Typeface.BOLD);setPadding(dp(14),dp(15),dp(8),dp(15))
        }
        root.addView(bar)
        val scroll=ScrollView(this).apply{fillViewport=true}
        content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(12),dp(10),dp(12),dp(18))}
        scroll.addView(content);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        status=TextView(this).apply {
            text="Sẵn sàng • Chưa xuất video";setTextColor(Color.WHITE);textSize=12f
            setBackgroundColor(0xff1e293b.toInt());setPadding(dp(12),dp(11),dp(12),dp(11))
        }
        root.addView(status);setContentView(root)
        buildScreen()
        if(Build.VERSION.SDK_INT>=33){registerReceiver(receiver,IntentFilter(ExportService.ACTION_STATUS),Context.RECEIVER_NOT_EXPORTED)}
        else registerReceiver(receiver,IntentFilter(ExportService.ACTION_STATUS))
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),10)
    }
    override fun onDestroy(){runCatching{unregisterReceiver(receiver)};model.save();super.onDestroy()}
    private fun dp(n:Int)=(resources.displayMetrics.density*n).toInt()
    private fun save(){model.save()}
    private fun state()=model.state()
    private fun section(title:String){
        content.addView(TextView(this).apply {
            text=title;textSize=17f;setTypeface(null,Typeface.BOLD)
            setTextColor(0xff0f172a.toInt());setPadding(0,dp(18),0,dp(7))
        })
    }
    private fun text(t:String,size:Float=13f, color:Int=0xff475569.toInt()):TextView=TextView(this).apply{
        this.text=t;this.textSize=size;setTextColor(color);setPadding(dp(2),dp(4),dp(2),dp(5))
    }
    private fun row():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
    private fun btn(label:String,fn:()->Unit):Button=Button(this).apply {
        text=label;isAllCaps=false;textSize=12f;setOnClickListener{fn()}
    }
    private fun addBtnRow(vararg items:Pair<String,()->Unit>) {
        val line=row()
        for((label,fn)in items)line.addView(btn(label,fn),LinearLayout.LayoutParams(0,dp(49),1f))
        content.addView(line)
    }
    private fun edit(label:String,value:String,onValue:(String)->Unit,integer:Boolean=false):EditText{
        val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        l.addView(text(label))
        val e=EditText(this).apply{
            setSingleLine(true);textSize=14f;setText(value)
            if(integer)inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            addTextChangedListener(object:TextWatcher{
                override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
                override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){onValue(s?.toString()?:"")}
                override fun afterTextChanged(s:Editable?){}
            })
        }
        l.addView(e);content.addView(l)
        return e
    }
    private fun slider(label:String,value:Int,max:Int=100,fn:(Int)->Unit){
        val row=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val t=text("$label: $value")
        row.addView(t)
        val s=SeekBar(this).apply{this.max=max;progress=value.coerceIn(0,max)}
        s.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(sb:SeekBar?,v:Int,user:Boolean){if(user){t.text="$label: $v";fn(v);canvas?.invalidate();save()}}
            override fun onStartTrackingTouch(sb:SeekBar?){}
            override fun onStopTrackingTouch(sb:SeekBar?){}
        })
        row.addView(s);content.addView(row)
    }
    private fun colorPalette(label:String,current:Int,onColor:(Int)->Unit){
        content.addView(text(label))
        val list=row()
        for(c in colors){
            val b=TextView(this).apply{
                text=if(c==current)"✓" else "";gravity=Gravity.CENTER
                setTextColor(if(c==Color.BLACK)Color.WHITE else Color.BLACK)
                setBackgroundColor(c);textSize=18f
                setOnClickListener{onColor(c);save();buildScreen()}
            }
            val lp=LinearLayout.LayoutParams(0,dp(36),1f);lp.setMargins(dp(2),0,dp(2),0)
            list.addView(b,lp)
        }
        content.addView(list)
        edit("Mã màu HEX (#RRGGBB) — nhấn nút Xong trên bàn phím để cập nhật",String.format("#%06X",current and 0xffffff),{
            if(it.matches(Regex("#[A-Fa-f0-9]{6}"))){onColor(Color.parseColor(it));canvas?.invalidate();save()}
        })
    }
    private fun pick(request:Int){
        val intent=Intent(Intent.ACTION_OPEN_DOCUMENT).apply{
            addCategory(Intent.CATEGORY_OPENABLE)
            type=when(request){REQ_VIDEO,REQ_VIDEO_LAYER->"video/*";REQ_AUDIO->"audio/*";
                REQ_IMAGE_LAYER->"image/*";else->"*/*"}
            if(request in listOf(REQ_INTRO,REQ_MIDDLE,REQ_OUTRO))putExtra(Intent.EXTRA_MIME_TYPES,arrayOf("image/*","video/*"))
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE,request in listOf(REQ_VIDEO,REQ_AUDIO,REQ_INTRO,REQ_MIDDLE,REQ_OUTRO))
        }
        startActivityForResult(intent,request)
    }
    @Deprecated("Android SAF result dispatch")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK || data==null)return
        if(requestCode==REQ_TREE){
            data.data?.let{
                contentResolver.takePersistableUriPermission(it,Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                model.outputTree=it.toString()
            }
            save();buildScreen();return
        }
        val uris=mutableListOf<Uri>()
        data.clipData?.let{c->for(i in 0 until c.itemCount)uris.add(c.getItemAt(i).uri)}
        data.data?.let {if(it !in uris)uris.add(it)}
        for(uri in uris){
            try {contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch(_:Exception){}
            val name=MediaInfo.title(this,uri)
            when(requestCode){
                REQ_VIDEO->if(model.videos.none{it.uri==uri.toString()})model.videos.add(VideoEntry(uri.toString(),name))
                REQ_AUDIO->if(uri.toString() !in model.audios)model.audios.add(uri.toString())
                REQ_IMAGE_LAYER->{state().imageLayer.uri=uri.toString();state().imageLayer.enabled=true}
                REQ_VIDEO_LAYER->{state().videoLayer.uri=uri.toString();state().videoLayer.enabled=true}
                REQ_INTRO,REQ_MIDDLE,REQ_OUTRO->{
                    val clip=InsertClip(uri.toString(),name,MediaInfo.isImage(this,uri),3000,pendingMiddleAtMs)
                    val dst=when(requestCode){REQ_INTRO->state().intro;REQ_MIDDLE->state().middle;else->state().outro}
                    dst.add(clip)
                }
            }
        }
        save();buildScreen()
    }
    private fun chooseFolder(){startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE),REQ_TREE)}
    private fun poster(uri:String):Bitmap?=try{
        val retriever=MediaMetadataRetriever()
        try {retriever.setDataSource(this,Uri.parse(uri));retriever.getFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST_SYNC)}
        finally{retriever.release()}
    }catch(_:Exception){null}
    private fun buildScreen(){
        content.removeAllViews()
        section("1. Nguồn video và audio")
        addBtnRow("+ Nhập video" to {pick(REQ_VIDEO)},"+ Nhạc nền" to {pick(REQ_AUDIO)},"Thư mục xuất" to {chooseFolder()})
        content.addView(text("Video: ${model.videos.size}   |   Audio: ${model.audios.size}   |   Nhạc: NGẪU NHIÊN (cố định theo từng video)"))
        content.addView(text(if(model.outputTree.isBlank())"Chưa chọn thư mục xuất MP4" else "Đã chọn thư mục xuất MP4"))
        for((i,v) in model.videos.withIndex()){
            val bar=row()
            val choose=btn("${if(i==model.selected)"▶ " else ""}${i+1}. ${v.name.take(26)}"){
                model.selected=i;save();buildScreen()
            }
            bar.addView(choose,LinearLayout.LayoutParams(0,dp(45),1f))
            bar.addView(btn("Xóa"){
                model.videos.removeAt(i);model.selected=model.selected.coerceAtMost((model.videos.size-1).coerceAtLeast(0));save();buildScreen()
            });content.addView(bar)
        }
        if(model.videos.isNotEmpty())addBtnRow("Xóa toàn bộ video" to {
            AlertDialog.Builder(this).setMessage("Xóa toàn bộ danh sách video nhập?")
                .setPositiveButton("Xóa"){_,_->model.videos.clear();model.selected=0;save();buildScreen()}
                .setNegativeButton("Hủy",null).show()
        })
        if(model.audios.isNotEmpty()){
            content.addView(text("Danh sách nhạc (chạm X để xóa):"))
            for((i,u) in model.audios.withIndex()){
                val bar=row();val name=Uri.parse(u).lastPathSegment?.takeLast(38) ?: "Audio"
                bar.addView(text("${i+1}. $name"),LinearLayout.LayoutParams(0,-2,1f))
                bar.addView(btn("X") {model.audios.removeAt(i);save();buildScreen()});content.addView(bar)
            }
        }
        if(model.videos.isEmpty()){
            content.addView(text("Chọn video để bật khung mô phỏng và công cụ chỉnh sửa.",14f))
            return
        }
        section("2. Cấu hình chỉnh sửa")
        val toggle=Switch(this).apply{
            text="Tùy chỉnh RIÊNG từng video (tắt = áp dụng chung)"
            textSize=13f;isChecked=model.useSeparate
            setOnCheckedChangeListener{_,checked->model.useSeparate=checked;save();buildScreen()}
        };content.addView(toggle)
        content.addView(text("Đang chọn: ${model.videos[model.selected].name}",14f))
        val s=state()
        section("3. Mô phỏng kéo thả")
        content.addView(text("Kéo chữ/ảnh/video để đổi vị trí; kéo chấm ở góc để đổi kích thước; hai ngón để thu phóng và xoay."))
        canvas=EditorCanvas(this).also { editor->
            editor.state=s
            val entry=model.videos[model.selected]
            editor.videoAspect=runCatching{MediaInfo.details(this,entry.uri).aspect}.getOrDefault(16f/9f)
            editor.poster=poster(entry.uri)
            editor.onEdit={save()}
            content.addView(editor)
        }
        addBtnRow("Chữ" to {canvas?.selected=Kind.TEXT},
            "Ảnh phủ" to {canvas?.selected=Kind.IMAGE},"Video phủ" to {canvas?.selected=Kind.VIDEO})
        edit("Nội dung chữ watermark",s.watermark,{s.watermark=it;canvas?.invalidate();save()})
        val enabled=Switch(this).apply{
            text="Hiển thị watermark chữ";isChecked=s.textLayer.enabled
            setOnCheckedChangeListener{_,v->s.textLayer.enabled=v;canvas?.invalidate();save()}
        };content.addView(enabled)
        colorPalette("Màu watermark",s.watermarkColor){s.watermarkColor=it}
        section("4. Tùy chỉnh đối tượng")
        val kind=canvas?.selected ?: Kind.TEXT
        content.addView(text("Chọn đối tượng trên khung ở phía trên, hoặc chọn bằng nút Chữ / Ảnh phủ / Video phủ."))
        addBtnRow("Đổi ảnh phủ" to {pick(REQ_IMAGE_LAYER)},"Đổi video phủ" to {pick(REQ_VIDEO_LAYER)})
        for((title,layer) in listOf("Chữ watermark" to s.textLayer,"Ảnh phủ" to s.imageLayer,"Video phủ" to s.videoLayer)){
            val sw=Switch(this).apply{
                text="Bật $title";isChecked=layer.enabled
                setOnCheckedChangeListener{_,v->layer.enabled=v;canvas?.invalidate();save()}
            };content.addView(sw)
            slider("$title - chiều rộng %",(layer.width*100).toInt(),180){layer.width=it.coerceAtLeast(3)/100f}
            slider("$title - độ mờ %",(layer.opacity*100).toInt()){layer.opacity=it/100f}
            slider("$title - xoay °",(layer.rotation+180).toInt(),360){layer.rotation=(it-180).toFloat()}
        }
        section("5. Khung và độ nghiêng video")
        val options=frameStyles.keys.toList()
        val spinner=Spinner(this)
        spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,frameStyles.values.toList())
        spinner.setSelection(options.indexOf(s.frameStyle).coerceAtLeast(0))
        spinner.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:android.widget.AdapterView<*>?){}
            override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,pos:Int,id:Long){
                s.frameStyle=options[pos];canvas?.invalidate();save()
            }
        }
        content.addView(spinner)
        colorPalette("Màu viền khung",s.frameColor){s.frameColor=it}
        slider("Độ dày khung (‰ cạnh ngắn)",(s.frameThickness*1000).toInt(),80){s.frameThickness=it.coerceAtLeast(1)/1000f}
        slider("Nghiêng video (°)",(s.videoTilt+45).toInt(),90){s.videoTilt=(it-45).toFloat()}
        section("6. Cắt đầu và cắt đuôi")
        edit("Cắt đầu (giây)","${s.trimStartMs/1000.0}",{
            it.toDoubleOrNull()?.let{v->s.trimStartMs=(v.coerceAtLeast(0.0)*1000).toLong();save()}
        },true)
        edit("Cắt đuôi (giây)","${s.trimEndMs/1000.0}",{
            it.toDoubleOrNull()?.let{v->s.trimEndMs=(v.coerceAtLeast(0.0)*1000).toLong();save()}
        },true)
        section("7. Chèn ảnh/video theo thời gian")
        content.addView(text("Thêm nhiều ảnh hoặc video, chỉnh thời lượng hiển thị ảnh, thứ tự và vị trí clip giữa. Các đoạn chèn mặc định bị tắt tiếng."))
        addBtnRow("+ Đầu video" to {pick(REQ_INTRO)},"+ Giữa video" to {askMiddleTime()},"+ Cuối video" to {pick(REQ_OUTRO)})
        showClips("ĐẦU VIDEO",s.intro)
        showClips("GIỮA VIDEO",s.middle)
        showClips("CUỐI VIDEO",s.outro)
        section("8. Preset và xuất hàng loạt")
        addBtnRow("Lưu preset" to {promptPreset()},"Nạp preset" to {choosePreset()})
        content.addView(text("MP4 • Âm thanh gốc bị loại bỏ • Mỗi video chọn ngẫu nhiên một nhạc trong danh sách và lặp cho đủ độ dài. Nếu không chọn audio: video không có tiếng."))
        addBtnRow("BẮT ĐẦU XUẤT VIDEO" to {startExport()},"DỪNG" to {
            startService(Intent(this,ExportService::class.java).setAction(ExportService.ACTION_CANCEL))
        })
    }
    private fun askMiddleTime(){
        val e=EditText(this).apply{inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL;setText("5")}
        AlertDialog.Builder(this).setTitle("Chèn vào giữa — giây tính từ đầu video sau khi cắt")
            .setView(e).setPositiveButton("Chọn ảnh/video"){_,_->
                pendingMiddleAtMs=((e.text.toString().toDoubleOrNull()?:0.0).coerceAtLeast(0.0)*1000).toLong()
                pick(REQ_MIDDLE)
            }.setNegativeButton("Hủy",null).show()
    }
    private fun showClips(label:String,clips:MutableList<InsertClip>){
        content.addView(text("$label — ${clips.size} clip",14f,0xff0f172a.toInt()))
        for((i,item) in clips.withIndex()){
            content.addView(text("${i+1}. ${if(item.image)"Ảnh" else "Video"}: ${item.name}",12f))
            if(item.image)edit("Ảnh hiển thị (giây) #${i+1}","${item.durationMs/1000.0}",{
                it.toDoubleOrNull()?.let{v->item.durationMs=(v.coerceIn(.1,3600.0)*1000).toLong();save()}
            },true)
            if(label=="GIỮA VIDEO")edit("Vị trí chèn (giây) #${i+1}","${item.atMs/1000.0}",{
                it.toDoubleOrNull()?.let{v->item.atMs=(v.coerceAtLeast(0.0)*1000).toLong();save()}
            },true)
            val bar=row()
            bar.addView(btn("↑") {if(i>0){val old=clips[i-1];clips[i-1]=clips[i];clips[i]=old;save();buildScreen()}},LinearLayout.LayoutParams(0,dp(43),1f))
            bar.addView(btn("↓") {if(i<clips.lastIndex){val old=clips[i+1];clips[i+1]=clips[i];clips[i]=old;save();buildScreen()}},LinearLayout.LayoutParams(0,dp(43),1f))
            bar.addView(btn("Xóa clip") {clips.removeAt(i);save();buildScreen()},LinearLayout.LayoutParams(0,dp(43),2f))
            content.addView(bar)
        }
    }
    private fun promptPreset(){
        val field=EditText(this).apply{setSingleLine(true);setText("Preset ${System.currentTimeMillis()/1000}")}
        AlertDialog.Builder(this).setTitle("Tên preset (lưu cấu hình chung)").setView(field)
            .setPositiveButton("Lưu"){_,_->
                if(field.text.isNotBlank()){
                    // If currently editing separately, save that as shared preset snapshot.
                    val old=model.shared;model.shared=state().copyDeep()
                    model.savePreset(field.text.toString());model.shared=old
                    Toast.makeText(this,"Đã lưu preset",Toast.LENGTH_SHORT).show()
                }
            }.setNegativeButton("Hủy",null).show()
    }
    private fun choosePreset(){
        val names=model.presets()
        if(names.isEmpty()){Toast.makeText(this,"Chưa có preset",Toast.LENGTH_SHORT).show();return}
        AlertDialog.Builder(this).setTitle("Chọn preset").setItems(names.toTypedArray()){_,i->
            model.loadPreset(names[i]);buildScreen()
        }.show()
    }
    private fun startExport(){
        if(model.videos.isEmpty()){toast("Chưa có video");return}
        if(model.outputTree.isBlank()){toast("Hãy chọn thư mục xuất");chooseFolder();return}
        model.save()
        AlertDialog.Builder(this).setTitle("Xuất ${model.videos.size} video?")
            .setMessage("Video được xuất lần lượt theo cấu hình ${if(model.useSeparate)"riêng" else "chung"}. Video lỗi tự thử lại một lần. Giữ đủ bộ nhớ trống và không tắt máy khi đang xử lý.")
            .setPositiveButton("Bắt đầu"){_,_->
                val i=Intent(this,ExportService::class.java).putExtra(ExportService.EXTRA_PROJECT,model.json().toString())
                if(Build.VERSION.SDK_INT>=26)startForegroundService(i) else startService(i)
                status.text="Đã gửi hàng đợi ${model.videos.size} video"
            }.setNegativeButton("Hủy",null).show()
    }
    private fun toast(msg:String)=Toast.makeText(this,msg,Toast.LENGTH_LONG).show()
}
