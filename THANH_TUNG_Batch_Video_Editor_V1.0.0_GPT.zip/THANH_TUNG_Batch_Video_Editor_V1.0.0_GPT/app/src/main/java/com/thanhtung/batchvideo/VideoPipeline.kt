package com.thanhtung.batchvideo

import android.content.Context
import android.net.Uri
import android.util.Size
import androidx.media3.common.MediaItem
import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.StaticOverlaySettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.VideoCompositorSettings
import java.util.Random

/** Pure composition builder. Inputs are persisted content URIs; outputs use device-supported codecs. */
@androidx.annotation.OptIn(UnstableApi::class)
class VideoPipeline(private val context: Context) {
    private val painter=LayerRenderer(context)
    private fun sourceEffects(tilt: Float): Effects = Effects(emptyList(),
        if(tilt==0f)emptyList() else listOf(ScaleAndRotateTransformation.Builder().setRotationDegrees(tilt).build()))
    private fun makeImageOrVideo(clip: InsertClip, tilt: Float): EditedMediaItem {
        val media = if(clip.image) MediaItem.Builder().setUri(clip.uri)
            .setImageDurationMs(clip.durationMs.coerceAtLeast(100)).build()
        else MediaItem.fromUri(Uri.parse(clip.uri))
        return EditedMediaItem.Builder(media).setRemoveAudio(true).setFrameRate(30)
            .setEffects(sourceEffects(tilt)).build()
    }
    private fun footage(uri: String, start: Long, end: Long, tilt: Float): EditedMediaItem {
        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(start)
            .setEndPositionMs(end)
            .build()
        return EditedMediaItem.Builder(MediaItem.Builder().setUri(uri)
            .setClippingConfiguration(clip).build()).setRemoveAudio(true)
            .setEffects(sourceEffects(tilt)).build()
    }
    fun create(video: VideoEntry, s: EditState, audioUri: String?): Composition {
        val src=MediaInfo.details(context,video.uri)
        val sourceDuration=src.durationMs
        require(sourceDuration>100) { "Không đọc được thời lượng video: ${video.name}" }
        val head=s.trimStartMs.coerceAtLeast(0)
        val tail=s.trimEndMs.coerceAtLeast(0)
        require(head+tail+100 < sourceDuration) { "Cắt đầu + đuôi quá dài: ${video.name}" }
        val remaining=sourceDuration-head-tail
        val items=mutableListOf<EditedMediaItem>()
        s.intro.forEach { items.add(makeImageOrVideo(it,s.videoTilt)) }
        var current=0L
        // Stable sort preserves the user-defined order for multiple clips at the same timestamp.
        for(add in s.middle.withIndex().sortedWith(compareBy<IndexedValue<InsertClip>> { it.value.atMs }.thenBy{it.index})) {
            val at=add.value.atMs.coerceIn(0,remaining)
            if(at>current){items.add(footage(video.uri,head+current,head+at,s.videoTilt));current=at}
            items.add(makeImageOrVideo(add.value,s.videoTilt))
        }
        if(current<remaining)items.add(footage(video.uri,head+current,sourceDuration-tail,s.videoTilt))
        s.outro.forEach { items.add(makeImageOrVideo(it,s.videoTilt)) }
        require(items.isNotEmpty()) { "Danh sách đoạn video rỗng" }
        val videoSeq=EditedMediaItemSequence.withVideoFrom(items)
        val sequences=mutableListOf(videoSeq)
        val overlay=s.videoLayer
        val overlayEnabled=overlay.enabled && overlay.uri.isNotBlank()
        if (overlayEnabled) {
            // Picture-in-picture video plays silently and loops to match the final composition.
            sequences.add(EditedMediaItemSequence.withVideoFrom(listOf(
                EditedMediaItem.Builder(MediaItem.fromUri(overlay.uri))
                    .setRemoveAudio(true).build()
            )).buildUpon().setIsLooping(true).build())
        }
        if (!audioUri.isNullOrBlank()) {
            val bg=EditedMediaItem.Builder(MediaItem.fromUri(audioUri))
                .setRemoveVideo(true).build()
            sequences.add(EditedMediaItemSequence.withAudioFrom(listOf(bg))
                .buildUpon().setIsLooping(true).build())
        }
        val videoEffects=mutableListOf<Effect>()
        // One common canvas size = input's original frame, also for added images/videos.
        videoEffects.add(Presentation.createForWidthAndHeight(
            src.width,src.height,Presentation.LAYOUT_SCALE_TO_FIT))
        painter.exportBitmap(s,src.width,src.height)?.let {
            videoEffects.add(OverlayEffect(listOf(BitmapOverlay.createStaticBitmapOverlay(it))))
        }
        val builder=Composition.Builder(sequences).setEffects(Effects(emptyList(),videoEffects))
        if (overlayEnabled) {
            val overlaySize=MediaInfo.details(context,overlay.uri)
            val scale=(src.width*overlay.width/overlaySize.width.coerceAtLeast(1)).coerceIn(.01f,10f)
            builder.setVideoCompositorSettings(object:VideoCompositorSettings {
                override fun getOutputSize(inputSizes: MutableList<Size>): Size = Size(src.width,src.height)
                override fun getOverlaySettings(inputId: Int,presentationTimeUs: Long):OverlaySettings =
                    if(inputId==1) StaticOverlaySettings.Builder()
                        .setOverlayFrameAnchor(0f,0f)
                        .setBackgroundFrameAnchor(overlay.x*2-1,1-overlay.y*2)
                        .setScale(scale,scale)
                        .setAlphaScale(overlay.opacity.coerceIn(0f,1f))
                        .setRotationDegrees(overlay.rotation)
                        .build()
                    else StaticOverlaySettings.Builder().build()
            })
        }
        return builder.build()
    }
    /** Repeatable random assignment, independent of job failures and retries. */
    fun pickAudio(all: List<String>, video: VideoEntry): String? = if (all.isEmpty()) null else
        all[Random(video.uri.hashCode().toLong() xor 0x4c2d9a73L).nextInt(all.size)]
}
