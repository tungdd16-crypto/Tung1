package com.thanhtung.batchvideo

import android.app.*
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.annotation.OptIn
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import org.json.JSONObject
import java.io.File

/** Foreground export queue. Keeps running across activity recreation, not device reboots. */
@OptIn(UnstableApi::class)
class ExportService: Service() {
    companion object {
        const val ACTION_STATUS="com.thanhtung.batchvideo.STATUS"
        const val ACTION_CANCEL="com.thanhtung.batchvideo.CANCEL"
        const val EXTRA_PROJECT="project"
        private const val CHANNEL="batch_exports"
    }
    private lateinit var project:Project
    private lateinit var pipeline:VideoPipeline
    private val handler=Handler(Looper.getMainLooper())
    private var worker:Transformer?=null
    private var active=false
    private var index=0
    private var done=0
    private var errors=0
    private var retry=0
    private var activeFile:File?=null
    private var canceled=false
    private var wake:PowerManager.WakeLock?=null
    private val progress=ProgressHolder()
    private val tick=object:Runnable{
        override fun run(){
            if (!active) return
            runCatching { worker?.getProgress(progress) }
            update("Đang xuất ${index+1}/${project.videos.size}: ${progress.progress}%", progress.progress)
            handler.postDelayed(this,900)
        }
    }
    override fun onCreate(){
        super.onCreate()
        val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL,"Xuất video hàng loạt",NotificationManager.IMPORTANCE_LOW))
    }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int {
        if(intent?.action==ACTION_CANCEL){
            canceled=true;active=false;worker?.cancel();activeFile?.delete()
            update("Đã hủy hàng đợi",0);stopSelf();return START_NOT_STICKY
        }
        if(active) return START_NOT_STICKY
        val raw=intent?.getStringExtra(EXTRA_PROJECT) ?: return START_NOT_STICKY
        project=Project(this)
        try { project.restore(JSONObject(raw)) }catch(e:Exception){stopSelf();return START_NOT_STICKY}
        if(project.videos.isEmpty() || project.outputTree.isBlank()){stopSelf();return START_NOT_STICKY}
        pipeline=VideoPipeline(this)
        canceled=false;index=0;done=0;errors=0;retry=0;active=true
        wake=(getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"thanhtung:video-export")
        wake?.acquire(6*60*60*1000L)
        startForeground(2101,notification("Khởi tạo hàng đợi xuất video",0))
        handler.post { next() }
        handler.post(tick)
        return START_NOT_STICKY
    }
    private fun notification(msg:String,percent:Int):Notification {
        val cancel=PendingIntent.getService(this,0,
            Intent(this,ExportService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this,CHANNEL).setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("THANH TUNG Batch Video Editor")
            .setContentText(msg).setOngoing(active)
            .setProgress(100,percent.coerceIn(0,100),false)
            .addAction(Notification.Action.Builder(null,"Dừng xuất",cancel).build()).build()
    }
    private fun update(msg:String,percent:Int){
        val n=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        n.notify(2101,notification(msg,percent))
        sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName)
            .putExtra("message",msg).putExtra("percent",percent)
            .putExtra("done",done).putExtra("errors",errors))
    }
    private fun next(){
        if(canceled)return
        if(index>=project.videos.size){
            active=false;handler.removeCallbacks(tick)
            update("Hoàn tất: $done thành công, $errors lỗi",100)
            stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();return
        }
        val item=project.videos[index]
        try {
            val edit=project.state(index).copyDeep()
            val composed=pipeline.create(item,edit,pipeline.pickAudio(project.audios,item))
            val dst=File(cacheDir,"batch_${index}_${System.currentTimeMillis()}.mp4")
            activeFile=dst
            worker=Transformer.Builder(this).addListener(object:Transformer.Listener{
                override fun onCompleted(composition:Composition,exportResult:ExportResult) {
                    if(canceled)return
                    runCatching { copyToFolder(dst,item.name,index) }
                        .onSuccess { done++;update("Đã lưu: ${item.name}",100) }
                        .onFailure { errors++;update("Lỗi lưu video ${item.name}: ${it.message}",0) }
                    dst.delete();retry=0;index++;handler.post{next()}
                }
                override fun onError(composition:Composition,exportResult:ExportResult,exception:ExportException){
                    if(canceled)return
                    dst.delete()
                    if(retry<1){retry++;update("Đang thử lại ${item.name}",0);handler.postDelayed({next()},400)}
                    else{retry=0;errors++;update("Lỗi ${item.name}: ${exception.message}",0);index++;handler.post{next()}}
                }
            }).build()
            worker!!.start(composed,dst.absolutePath)
        }catch(e:Exception){
            if(retry<1){retry++;update("Thử lại: ${e.message}",0);handler.postDelayed({next()},400)}
            else{errors++;retry=0;update("Bỏ qua ${item.name}: ${e.message}",0);index++;handler.post{next()}}
        }
    }
    private fun copyToFolder(file:File,name:String,number:Int){
        val tree=DocumentFile.fromTreeUri(this,Uri.parse(project.outputTree))
            ?: error("Thư mục đầu ra không hợp lệ")
        val base=name.substringBeforeLast('.',name).replace(Regex("[^\\p{L}\\p{N}_. -]"),"_")
            .take(80).ifBlank { "video" }
        val title="TT_${(number+1).toString().padStart(3,'0')}_${base}.mp4"
        val target=tree.createFile("video/mp4",title) ?: error("Không tạo được tệp đích")
        try {
            contentResolver.openOutputStream(target.uri,"w")?.use { out -> file.inputStream().use { it.copyTo(out) } }
                ?: error("Không ghi được tệp đích")
        }catch(e:Exception){target.delete();throw e}
    }
    override fun onDestroy(){active=false;handler.removeCallbacks(tick);worker?.cancel();
        if(wake?.isHeld==true)wake?.release();super.onDestroy()}
    override fun onBind(intent:Intent?):IBinder?=null
}
