package com.thanhtung.batchvideo

import android.content.Context
import android.graphics.*
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import kotlin.math.*

/** Same normalized overlay and border painting is used by preview and final MP4 export. */
class LayerRenderer(private val context: Context) {
    private val images = mutableMapOf<String, Bitmap?>()
    fun bitmapForUri(uri: String): Bitmap? {
        if (uri.isBlank()) return null
        if (!images.containsKey(uri)) {
            images[uri] = runCatching {
                if ((context.contentResolver.getType(Uri.parse(uri)) ?: "").startsWith("video/")) {
                    val r = MediaMetadataRetriever()
                    try {
                        r.setDataSource(context, Uri.parse(uri))
                        r.getFrameAtTime(0L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    } finally { r.release() }
                } else context.contentResolver.openInputStream(Uri.parse(uri))?.use {
                    BitmapFactory.decodeStream(it)
                }
            }.getOrNull()
        }
        return images[uri]
    }
    fun aspect(uri: String): Float = bitmapForUri(uri)?.let {
        it.width.toFloat() / it.height.coerceAtLeast(1)
    } ?: 16f / 9f
    fun box(layer: Layer, kind: Kind, state: EditState, w: Int, h: Int): RectF {
        val bw = max(1f,w*layer.width)
        val bh = when (kind) {
            Kind.TEXT -> bw / max(2f, state.watermark.length * .75f)
            Kind.IMAGE, Kind.VIDEO -> bw / aspect(layer.uri).coerceAtLeast(.05f)
        }
        return RectF(w*layer.x - bw/2, h*layer.y-bh/2, w*layer.x+bw/2,h*layer.y+bh/2)
    }
    fun draw(canvas: Canvas, s: EditState, w: Int, h: Int, showVideoFrame: Boolean = true) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        for ((kind, layer) in listOf(Kind.IMAGE to s.imageLayer, Kind.VIDEO to s.videoLayer)) {
            if (!layer.enabled || layer.uri.isBlank()) continue
            if (kind == Kind.VIDEO && !showVideoFrame) continue // Export video is composed as its own sequence.
            val bmp = bitmapForUri(layer.uri) ?: continue
            val b = box(layer,kind,s,w,h)
            p.alpha = (255*layer.opacity.coerceIn(0f,1f)).toInt()
            canvas.save();canvas.rotate(layer.rotation,b.centerX(),b.centerY())
            canvas.drawBitmap(bmp,null,b,p);canvas.restore()
        }
        drawFrame(canvas,s,w,h)
        if (s.textLayer.enabled && s.watermark.isNotBlank()) {
            val layer = s.textLayer
            val b=box(layer,Kind.TEXT,s,w,h)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            paint.typeface = Typeface.create("sans-serif-bold",Typeface.BOLD)
            paint.textSize=120f
            paint.textSize = 120f*b.width()/paint.measureText(s.watermark).coerceAtLeast(1f)
            paint.color=s.watermarkColor
            paint.alpha=(255*layer.opacity.coerceIn(0f,1f)).toInt()
            paint.setShadowLayer(max(1f,w*.001f),1f,1f,Color.BLACK)
            canvas.save();canvas.rotate(layer.rotation,b.centerX(),b.centerY())
            canvas.drawText(s.watermark,b.centerX()-paint.measureText(s.watermark)/2,
                b.centerY()-(paint.ascent()+paint.descent())/2,paint)
            canvas.restore()
        }
    }
    fun drawFrame(c: Canvas,s: EditState,w: Int,h: Int) {
        val style=s.frameStyle
        if(style=="NONE")return
        val t=(min(w,h)*s.frameThickness).coerceAtLeast(1f)
        val p=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=s.frameColor;this.style=Paint.Style.STROKE;strokeWidth=t }
        val r=RectF(t/2,t/2,w-t/2,h-t/2)
        when(style) {
            "SOLID" -> c.drawRect(r,p)
            "DASHED" -> { p.pathEffect=DashPathEffect(floatArrayOf(t*4,t*2),0f);c.drawRect(r,p) }
            "DOUBLE" -> { c.drawRect(r,p);val i=t*2.4f;r.inset(i,i);if(r.width()>0 && r.height()>0)c.drawRect(r,p) }
            "ROUNDED" -> c.drawRoundRect(r,t*5,t*5,p)
            "CORNERS" -> {
                val a=min(w,h)*.16f
                val path=Path()
                listOf(
                    floatArrayOf(0f,a,0f,0f,a,0f),
                    floatArrayOf(w-a,0f,w.toFloat(),0f,w.toFloat(),a),
                    floatArrayOf(0f,h-a,0f,h.toFloat(),a,h.toFloat()),
                    floatArrayOf(w-a,h.toFloat(),w.toFloat(),h.toFloat(),w.toFloat(),h-a)
                ).forEach { q -> path.moveTo(q[0],q[1]);path.lineTo(q[2],q[3]);path.lineTo(q[4],q[5]) }
                c.drawPath(path,p)
            }
        }
    }
    fun exportBitmap(s: EditState,w: Int,h: Int): Bitmap? {
        if (s.frameStyle=="NONE" && (!s.textLayer.enabled || s.watermark.isBlank()) &&
            (!s.imageLayer.enabled || s.imageLayer.uri.isBlank())) return null
        require(w in 1..8192 && h in 1..8192) { "Video dimensions too large" }
        return Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888).also { draw(Canvas(it),s,w,h,false) }
    }
}

enum class Kind { TEXT,IMAGE,VIDEO }

/** Preview displays first frame of main video; drag, pinch, rotate and resize by handle. */
class EditorCanvas(context: Context): View(context) {
    var state: EditState=EditState()
        set(value){field=value;invalidate()}
    var videoAspect=16f/9f
        set(value){field=value;requestLayout();invalidate()}
    var poster: Bitmap? = null
        set(value){field=value;invalidate()}
    var selected: Kind=Kind.TEXT
        set(value){field=value;invalidate()}
    var onEdit:(()->Unit)?=null
    private val r=LayerRenderer(context)
    private val blue=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.CYAN;style=Paint.Style.STROKE;strokeWidth=3f }
    private val white=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.WHITE }
    private var drawLeft=0f; private var drawTop=0f; private var drawW=1f; private var drawH=1f
    private var px=0f;private var py=0f;private var oldAngle:Double?=null
    private var resizing=false
    private val pinch=ScaleGestureDetector(context,object:ScaleGestureDetector.SimpleOnScaleGestureListener(){
        override fun onScale(d:ScaleGestureDetector):Boolean {
            current().width=(current().width*d.scaleFactor).coerceIn(.03f,1.8f)
            invalidate();onEdit?.invoke();return true
        }
    })
    private fun current()=when(selected){Kind.TEXT->state.textLayer;Kind.IMAGE->state.imageLayer;Kind.VIDEO->state.videoLayer}
    override fun onMeasure(wSpec:Int,hSpec:Int) {
        val w=MeasureSpec.getSize(wSpec)
        val target=(w/videoAspect).toInt()
        val cap=(resources.displayMetrics.density*490).toInt()
        setMeasuredDimension(w,min(target,cap).coerceAtLeast(130))
    }
    override fun onDraw(c:Canvas) {
        super.onDraw(c)
        val a=videoAspect.coerceAtLeast(.2f)
        drawW=min(width.toFloat(),height*a);drawH=drawW/a
        drawLeft=(width-drawW)/2;drawTop=(height-drawH)/2
        c.drawColor(Color.rgb(14,20,31))
        c.save();c.translate(drawLeft,drawTop);c.clipRect(0f,0f,drawW,drawH)
        val w=drawW.roundToInt();val h=drawH.roundToInt()
        c.drawColor(Color.rgb(36,50,69))
        poster?.let { bmp ->
            c.save();c.rotate(state.videoTilt,drawW/2,drawH/2)
            c.drawBitmap(bmp,null,RectF(0f,0f,drawW,drawH),Paint(Paint.FILTER_BITMAP_FLAG))
            c.restore()
        }
        r.draw(c,state,w,h)
        val layer=current()
        if (layer.enabled && (selected==Kind.TEXT && state.watermark.isNotEmpty() ||
             selected!=Kind.TEXT && layer.uri.isNotBlank())) {
            val b=r.box(layer,selected,state,w,h)
            c.save();c.rotate(layer.rotation,b.centerX(),b.centerY())
            c.drawRect(b,blue)
            c.drawCircle(b.right,b.bottom,13f,white)
            c.drawCircle(b.right,b.bottom,13f,blue)
            c.restore()
        }
        c.restore()
    }
    private fun coords(e:MotionEvent):Pair<Float,Float> = Pair(e.x-drawLeft,e.y-drawTop)
    override fun onTouchEvent(e:MotionEvent):Boolean {
        pinch.onTouchEvent(e)
        val (x,y)=coords(e)
        when(e.actionMasked){
            MotionEvent.ACTION_DOWN -> {
                val order=listOf(Kind.TEXT,Kind.IMAGE,Kind.VIDEO)
                for(k in order){
                    val layer=when(k){Kind.TEXT->state.textLayer;Kind.IMAGE->state.imageLayer;Kind.VIDEO->state.videoLayer}
                    if (!layer.enabled || k!=Kind.TEXT && layer.uri.isBlank())continue
                    val b=r.box(layer,k,state,drawW.roundToInt(),drawH.roundToInt())
                    b.inset(-22f,-22f)
                    if(b.contains(x,y)){selected=k;break}
                }
                val b=r.box(current(),selected,state,drawW.roundToInt(),drawH.roundToInt())
                resizing=hypot((b.right-x).toDouble(),(b.bottom-y).toDouble())<45.0
                px=x;py=y;oldAngle=null;invalidate();return true
            }
            MotionEvent.ACTION_POINTER_DOWN -> { if (e.pointerCount>=2) oldAngle=angle(e);return true }
            MotionEvent.ACTION_MOVE -> {
                if(e.pointerCount>=2) {
                    oldAngle?.let{last->
                        val now=angle(e)
                        var d=Math.toDegrees(now-last).toFloat();if(d>180)d-=360f;if(d< -180)d+=360f
                        current().rotation+=d;oldAngle=now
                    }
                } else if (!pinch.isInProgress){
                    if(resizing)current().width=(current().width+(x-px)/drawW.coerceAtLeast(1f)).coerceIn(.03f,1.8f)
                    else {
                        current().x=(current().x+(x-px)/drawW.coerceAtLeast(1f)).coerceIn(0f,1f)
                        current().y=(current().y+(y-py)/drawH.coerceAtLeast(1f)).coerceIn(0f,1f)
                    }
                    px=x;py=y
                }
                invalidate();onEdit?.invoke();return true
            }
            MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL->{resizing=false;oldAngle=null;onEdit?.invoke();performClick();return true}
        }
        return true
    }
    override fun performClick():Boolean {super.performClick();return true}
    private fun angle(e:MotionEvent)=atan2((e.getY(1)-e.getY(0)).toDouble(),(e.getX(1)-e.getX(0)).toDouble())
}
