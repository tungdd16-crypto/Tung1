@echo off
REM Needs Android SDK, Java 17, Gradle 8.11.1 on PATH.
gradle :app:assembleDebug --stacktrace
if errorlevel 1 (
  echo Build failed; check Android SDK and Gradle configuration.
  exit /b 1
)
echo APK: app\build\outputs\apk\debug\app-debug.apk
