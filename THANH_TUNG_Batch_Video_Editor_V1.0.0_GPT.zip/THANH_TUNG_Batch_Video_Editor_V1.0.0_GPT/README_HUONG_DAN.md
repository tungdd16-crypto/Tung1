# THANH TUNG Batch Video Editor — Android V1.0.0 GPT

## Tình trạng giao hàng

Đây là **dự án mã nguồn Android**, chưa phải APK đã được biên dịch hoặc chạy kiểm thử trên điện thoại. Trong môi trường tạo gói này không có Android SDK hoặc Gradle nên không thể xác nhận build thành công hay chất lượng xuất trên thiết bị thật. Mã nguồn sử dụng Android Media3 1.11.1 và API của Android SDK 35.

## Các tính năng đã lập trình

1. Chọn nhiều video qua trình quản lý tệp Android (SAF), chọn nhiều nhạc MP3/M4A/WAV tùy bộ giải mã thiết bị.
2. Watermark chữ: sửa nội dung, màu, độ rộng, độ trong suốt, vị trí, xoay; kéo/chụm trên khung preview, kéo chấm góc để đổi kích thước.
3. Lớp phủ ảnh và lớp phủ video có biến đổi vị trí, độ rộng, xoay, độ trong suốt. Lớp phủ video lặp âm thanh tắt, xử lý picture-in-picture theo API VideoCompositorSettings.
4. Khung video: không viền, viền liền, viền đứt, viền đôi, bo góc, bốn góc. Chọn màu và độ dày tương đối với khung. Nghiêng hình video từ -45° đến +45°.
5. Cắt đầu/đuôi bằng giây; chèn nhiều ảnh/video trước, tại các mốc giữa sau cắt, và sau video. Ảnh đặt được thời lượng riêng; video chèn giữ độ dài nguồn, không giữ âm thanh gốc.
6. Nhạc nền ngẫu nhiên từ danh sách, chọn ổn định theo video (không đổi khi lỗi render/retry), phát lặp đến hết video. Không đưa âm thanh gốc của footage và clip chèn vào xuất cuối.
7. Cấu hình chung/riêng theo video, lưu project bằng SharedPreferences, lưu và nạp preset chỉnh sửa.
8. Hàng đợi tuần tự chạy Foreground Service, thông báo tiến độ, tự thử lại một lần khi thất bại, lưu MP4 vào thư mục người dùng chọn. Dừng thủ công từ giao diện hoặc notification.

## Hướng dẫn build APK

1. Mở thư mục dự án trong **Android Studio** với JDK 17, Android SDK 35 và Gradle 8.11.1 (AGP 8.9.2, Kotlin 2.2.21).
2. Đồng bộ Gradle; nếu môi trường không tự sinh Wrapper JAR, dùng Gradle cài đặt sẵn chạy `gradle wrapper --gradle-version 8.11.1`, sau đó đồng bộ lại.
3. Chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**, hoặc chạy `./gradlew :app:assembleDebug` (`gradlew.bat` trên Windows).
4. APK debug sau khi build nằm ở `app/build/outputs/apk/debug/app-debug.apk`.
5. Cấp quyền chọn tệp, chọn thư mục xuất bằng nút "Thư mục xuất", sau đó bấm "BẮT ĐẦU XUẤT VIDEO".

## Build APK tự động qua GitHub (không cần máy cài Android Studio)

Đưa mã nguồn trong ZIP lên một repository GitHub, vào **Actions > Android APK Debug > Run workflow**. Khi hoàn tất, tải artifact `THANH_TUNG_Batch_Video_Editor_Debug_APK`; trong artifact có `app-debug.apk`. Đây là APK debug dùng thử (không phải bản ký phát hành Google Play). Workflow tải Android SDK và Gradle từ Internet.

## Giới hạn cần kiểm thử trên máy thật

- Khung preview hiển thị **khung hình tĩnh đầu tiên**, không phải phát lại video thời gian thực. Lớp phủ video hiển thị khung đầu nhưng được đưa vào chuỗi video động khi xuất.
- Một số tệp HDR, HEVC, định dạng độc lạ hoặc nhiều chuỗi ghép có thể bị codec điện thoại từ chối. Media3 không bảo đảm tất cả thiết bị hỗ trợ mọi tổ hợp đầu vào. Xuất không có hiệu ứng chuyển cảnh giữa các clip (chuyển cứng).
- Độ phân giải của **main video** được giữ cho mỗi mục, ảnh/clip chèn vừa khung. Yêu cầu giữ nguyên tỉ lệ video được thực hiện bằng canvas tỷ lệ gốc của mỗi main video; video ghép vào có thể xuất hiện thanh đen để không bị méo.
- Nghiêng video có thể tạo phần góc trống. Không được tự động phóng/cắt lấp các góc.
- Lớp phủ, khung và watermark được đồng bộ theo tọa độ tương đối giữa video ngang/dọc. Media3 xuất video overlay bằng compositor, cần test sai số vị trí/scale trên thiết bị.
- Quá trình hàng loạt cần duy trì đủ pin, bộ nhớ trống, và điện thoại đang bật. Android 15 có thể giới hạn thời lượng foreground media processing; hàng đợi sẽ không tự tiếp tục sau khi khởi động lại điện thoại.
- Không có chức năng sửa âm thanh theo beat, keyframe nâng cao, nhiều lớp phủ cùng loại, chuyển cảnh, xử lý nhạc ngắn bằng cách nối nhiều file trong 1 video. 

## Cấu trúc

- `Project.kt`: model + lưu/tải + metadata
- `LayerRenderer.kt`: canvas preview, gesture, khung và watermark raster
- `VideoPipeline.kt`: ghép timeline Media3 + compositor overlay + thay audio
- `ExportService.kt`: hàng đợi xuất qua foreground service + Android SAF
- `MainActivity.kt`: giao diện tiếng Việt + trình chọn tệp, preset, điều khiển

## Quyền và quyền riêng tư

Ứng dụng không dùng máy chủ, tài khoản hoặc quyền đọc toàn bộ kho ảnh; chỉ truy cập URI do người dùng chọn qua Storage Access Framework. `WAKE_LOCK` chỉ dùng khi xuất hàng loạt để giảm rủi ro Android ngủ giữa chừng. Nội dung không được tự động tải lên Internet.
