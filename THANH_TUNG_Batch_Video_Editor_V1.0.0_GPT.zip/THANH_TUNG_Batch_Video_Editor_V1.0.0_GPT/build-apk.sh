#!/usr/bin/env sh
# Needs Android SDK, Java 17, Gradle 8.11.1 on PATH.
set -eu
gradle :app:assembleDebug --stacktrace
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
